<?php

add_filter ( 'vc_grid_get_grid_data_access', '__return_true' );
