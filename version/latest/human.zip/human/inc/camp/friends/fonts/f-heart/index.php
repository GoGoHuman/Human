<?php
 echo "I am Human - are you?";
?>