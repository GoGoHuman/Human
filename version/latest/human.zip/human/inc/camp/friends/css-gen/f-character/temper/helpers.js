function toggle_human_gif(hide) {

            if (hide) {
                        jQuery('.human-loading-gif-wrapper').fadeOut();
            } else {
                        jQuery('.human-loading-gif-wrapper').css('display', 'table');
            }
}
toggle_human_gif();






