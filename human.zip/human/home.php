<?php

/*
 * Template Name: Home Page
 *
 *  @package human
 */

get_header ();

$template = 'Home';

if ( get_post_meta ( get_the_ID (), 'human_template' ) && ! empty ( get_post_meta ( get_the_ID (), 'human_template' ) ) ) {
            $template = get_post_meta ( get_the_ID (), 'human_template' );
}
?>
<?php

echo do_shortcode ( '[smartslider3 slider=2]' );
?>


<?php echo do_shortcode ( '[human_template name="' . $template . '"]' ) ?>

<?php get_footer (); ?>
