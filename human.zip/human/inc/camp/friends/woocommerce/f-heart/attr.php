<select name='state' id='state' class='fieldlook1'>
          <option value="">All States</option>
          <option value='CA' >CA</option>
          <option value='CO' >CO</option>
          <option value='CT' >CT</option>
          <option value='DC' >DC</option>
          <option value='FL' >FL</option>
          <option value='GA' >GA</option>
          <option value='HI' >HI</option>
          <option value='IL' >IL</option>
          <option value='KY' >KY</option>
          <option value='LA' >LA</option>
          <option value='MA' >MA</option>
          <option value='MD' >MD</option>
          <option value='MI' >MI</option>
          <option value='MN' >MN</option>
          <option value='MS' >MS</option>
          <option value='NC' >NC</option>
          <option value='NJ' >NJ</option>
          <option value='NV' >NV</option>
          <option value='NY' >NY</option>
          <option value='OH' >OH</option>
          <option value='OK' >OK</option>
          <option value='OR' >OR</option>
          <option value='PA' >PA</option>
          <option value='RI' >RI</option>
          <option value='SC' >SC</option>
          <option value='TX' >TX</option>
          <option value='VA' >VA</option>
</select>
</td></tr>

<tr id="city1"> <td><strong>City:</strong></td>
          <td>
                    <select name='city' id='city' class='fieldlook1' style="height:35px!important; width:340px !important;">
                              <option value="">All Cities</option>
                              <option value='Worcester' >Worcester</option>
                              <option value='Wilmington' >Wilmington</option>
                              <option value='Weston' >Weston</option>
                              <option value='West Chester' >West Chester</option>
                              <option value='Wellington' >Wellington</option>
                              <option value='Wayland' >Wayland</option>
                              <option value='Washington' >Washington</option>
                              <option value='The Woodlands' >The Woodlands</option>
                              <option value='Tallahassee' >Tallahassee</option>
                              <option value='Syracuse' >Syracuse</option>
                              <option value='Summit' >Summit</option>
                              <option value='St. Petersburg' >St. Petersburg</option>
                              <option value='Southlake ' >Southlake </option>
                              <option value='Somerset' >Somerset</option>
                              <option value='Sherman Oaks' >Sherman Oaks</option>
                              <option value='Santa Monica ' >Santa Monica </option>
                              <option value='San Antonio' >San Antonio</option>
                              <option value='Saint James' >Saint James</option>
                              <option value='Sacramento Area' >Sacramento Area</option>
                              <option value='Richmond' >Richmond</option>
                              <option value='Potomac' >Potomac</option>
                              <option value='Portland' >Portland</option>
                              <option value='Pearland' >Pearland</option>
                              <option value='Oklahoma City ' >Oklahoma City </option>
                              <option value='Norwell' >Norwell</option>
                              <option value='North Ridgeville' >North Ridgeville</option>
                              <option value='New Orleans' >New Orleans</option>
                              <option value='New Milford' >New Milford</option>
                              <option value='Naples' >Naples</option>
                              <option value='Naperville' >Naperville</option>
                              <option value='Morristown' >Morristown</option>
                              <option value='Minneapolis' >Minneapolis</option>
                              <option value='Long Beach' >Long Beach</option>
                              <option value='Littleton' >Littleton</option>
                              <option value='Lexington' >Lexington</option>
                              <option value='La Jolla (La Jolla CDS)' >La Jolla (La Jolla CDS)</option>
                              <option value='Katy' >Katy</option>
                              <option value='Jackson' >Jackson</option>
                              <option value='Houston-St Francis' >Houston-St Francis</option>
                              <option value='Houston- Briargrove' >Houston- Briargrove</option>
                              <option value='Houston - Travis' >Houston - Travis</option>
                              <option value='Houston' >Houston</option>
                              <option value='Honolulu' >Honolulu</option>
                              <option value='Henderson' >Henderson</option>
                              <option value='Hartford' >Hartford</option>
                              <option value='Harrisburg' >Harrisburg</option>
                              <option value='Ft. Worth' >Ft. Worth</option>
                              <option value='Frankfort' >Frankfort</option>
                              <option value='Fort Myers' >Fort Myers</option>
                              <option value='Englewood/Denver' >Englewood/Denver</option>
                              <option value='East Greenwich' >East Greenwich</option>
                              <option value='Dallas (Hockaday School)' >Dallas (Hockaday School)</option>
                              <option value='Dallas' >Dallas</option>
                              <option value='Congers' >Congers</option>
                              <option value='Colorado Springs' >Colorado Springs</option>
                              <option value='Cincinnati' >Cincinnati</option>
                              <option value='Chicago' >Chicago</option>
                              <option value='Charlottesville' >Charlottesville</option>
                              <option value='Charlotte' >Charlotte</option>
                              <option value='Charleston' >Charleston</option>
                              <option value='Buffalo' >Buffalo</option>
                              <option value='Bryn Mawr' >Bryn Mawr</option>
                              <option value='Boulder' >Boulder</option>
                              <option value='Beverly Hills' >Beverly Hills</option>
                              <option value='Baton Rouge' >Baton Rouge</option>
                              <option value='Baltimore' >Baltimore</option>
                              <option value='Austin' >Austin</option>
                              <option value='Augusta' >Augusta</option>
                              <option value='Arlington' >Arlington</option>
                    </select>
          </span>
</td>

</tr>
<tr><td></td><td><input type="button"  id="conti" value="continue" style="width: 115px;
                        height: 40px;
                        margin: 6px 90px;"/></td></tr>

<tr id="location1"><td><strong>Location:</strong></td>
          <td>
                    <select name='location' id='location' class='fieldlook1' style='width:300px; height:30px;'>
                              <option value="">All Locations</option>
                              <option value='1 Education Place' >1 Education Place</option>
                              <option value='Abundant Life School' >Abundant Life School</option>
                              <option value='Academy of Lifelong Learning' >Academy of Lifelong Learning</option>
                              <option value='All Saints Episcopal School' >All Saints Episcopal School</option>
                              <option value='Augusta Preparatory Day School' >Augusta Preparatory Day School</option>
                              <option value='Avon Old Farms School' >Avon Old Farms School</option>
                              <option value='Bancroft School' >Bancroft School</option>
                              <option value='Boulder Country Day School' >Boulder Country Day School</option>
                              <option value='Briargrove Elementary' >Briargrove Elementary</option>
                              <option value='Canterbury School' >Canterbury School</option>
                              <option value='Cape Fear Academy' >Cape Fear Academy</option>
                              <option value='Capital Day School' >Capital Day School</option>
                              <option value='Charlotte Latin School' >Charlotte Latin School</option>
                              <option value='Christ Community School' >Christ Community School</option>
                              <option value='Christian Brothers Academy' >Christian Brothers Academy</option>
                              <option value='College of Saint Elizabeth' >College of Saint Elizabeth</option>
                              <option value='Country Day School of the Sacred Heart' >Country Day School of the Sacred Heart</option>
                              <option value='Crosspoint Community Church' >Crosspoint Community Church</option>
                              <option value='Crossroads School' >Crossroads School</option>
                              <option value='De Vry University ' >De Vry University </option>
                              <option value='DePaul University (Naperville Campus)' >DePaul University (Naperville Campus)</option>
                              <option value='DePaul University (O'Hare campus)' >DePaul University (O'Hare campus)</option>
                              <option value='Detroit Country Day School' >Detroit Country Day School</option>
                              <option value='Epiphany Lutheran School' >Epiphany Lutheran School</option>
                              <option value='First Church Unitarian' >First Church Unitarian</option>
                              <option value='Georgetown Day School' >Georgetown Day School</option>
                              <option value='Harbor Country Day School' >Harbor Country Day School</option>
                              <option value='Harrisburg Academy' >Harrisburg Academy</option>
                              <option value='Heritage Hall' >Heritage Hall</option>
                              <option value='Integrity Academy' >Integrity Academy</option>
                              <option value='Kent Place School' >Kent Place School</option>
                              <option value='La Jolla Country Day School' >La Jolla Country Day School</option>
                              <option value='Lake Ridge Academy' >Lake Ridge Academy</option>
                              <option value='Maclay School' >Maclay School</option>
                              <option value='Maryknoll School' >Maryknoll School</option>
                              <option value='Minnehaha Academy -Enrichment page 5' >Minnehaha Academy -Enrichment page 5</option>
                              <option value='Nardin Academy' >Nardin Academy</option>
                              <option value='National Cathedral School' >National Cathedral School</option>
                              <option value='Park School' >Park School</option>
                              <option value='Porter-Gaud School' >Porter-Gaud School</option>
                              <option value='Rockland Country Day School' >Rockland Country Day School</option>
                              <option value='Rocky Hill School' >Rocky Hill School</option>
                              <option value='Rutgers Preparatory School' >Rutgers Preparatory School</option>
                              <option value='Shorecrest Preparatory School' >Shorecrest Preparatory School</option>
                              <option value='Skills for Living' >Skills for Living</option>
                              <option value='Southlake Tutoring Academy' >Southlake Tutoring Academy</option>
                              <option value='St. Andrews Episcopal School' >St. Andrews Episcopal School</option>
                              <option value='St. Christopher's School' >St. Christopher's School</option>
                              <option value='St. Francis Episcopal Day School' >St. Francis Episcopal Day School</option>
                              <option value='St. Lukes Episcopal School' >St. Lukes Episcopal School</option>
                              <option value='St. Martin's Episcopal School' >St. Martin's Episcopal School</option>
                              <option value='St. Mary's Academy' >St. Mary's Academy</option>
                              <option value='Summit County Day School' >Summit County Day School</option>
                              <option value='The Catlin Gabel School' >The Catlin Gabel School</option>
                              <option value='The Colorado Springs School' >The Colorado Springs School</option>
                              <option value='The Community School of Naples' >The Community School of Naples</option>
                              <option value='The Covenant School' >The Covenant School</option>
                              <option value='The Hockaday School' >The Hockaday School</option>
                              <option value='The Oakridge School' >The Oakridge School</option>
                              <option value='The Rubicon Academy ' >The Rubicon Academy </option>
                              <option value='The Sagemont School' >The Sagemont School</option>
                              <option value='The Sayre School' >The Sayre School</option>
                              <option value='The Steward School' >The Steward School</option>
                              <option value='Tottenberry's' >Tottenberry's</option>
                              <option value='Travis Elementary School' >Travis Elementary School</option>
                              <option value='Wayland Community Center' >Wayland Community Center</option>
                              <option value='Westtown School' >Westtown School</option>

                    </select>

