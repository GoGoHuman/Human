<?php

/*
 *  @param connect-db
 *  @author SergeDirect <itpal24@gmail.com>
 *  
 */




require_once('lib/BackupClass.php');

//Database Configurations Array
$config = array (
            'host' => DB_HOST,
            'login' => DB_USER,
            'password' => DB_PASSWORD,
            'database_name' => DB_NAME );



//Amazon S3 Configurations Array (Optional)
/*
$amazonConfig = array('accessKey' => '{YOUR S3 ACCESS KEY}',
				 	  'secretKey' =>  '{Your S3 Secret Key}',
				  	  'bucketName' => '{Your Bucket}');
*/