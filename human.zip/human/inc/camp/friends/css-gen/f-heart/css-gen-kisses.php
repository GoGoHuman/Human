<?php

/**
 * @package Human
 * @subpackage CSS Genrator
 * @author Sergei Pavlov <itpal24@gmail.com>
 */
if (!defined('ABSPATH')) {
            exit;
} // Exit if accessed directly

$HumanCssGen = new HumanCssGen();

$HumanCssGen->init();

class HumanCssGen {

            public function init() {

                        add_action(
                                'wp_enqueue_scripts', array(
                            &$this,
                            'scripts')
                        );
            }

            public function scripts() {


                        wp_dequeue_style('human-child-css');
                        wp_enqueue_style('human-child-css', HUMAN_CHILD_URL . '/style.css', array(
                            'human-dynamic-css'));
            }

            public function get() {

            }

}

add_action('wp_ajax_dynamic_css', 'dynamic_css');
add_action('wp_ajax_nopriv_dynamic_css', 'dynamic_css');

function dynamic_css() {

            header('Content-type: text/css');


            if (get_option('STYLE-GENS-MINIFIED')) {
                        echo html_entity_decode(stripslashes(get_option('STYLE-GENS-MINIFIED')));
            }
            die();
}

/* gets the data from a URL */

function human_get_url_data($url) {
            $ch = curl_init();
            $timeout = 5;
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            $data = curl_exec($ch);
            curl_close($ch);
            return $data;
}

add_action('wp_ajax_cssGenAjax', 'cssGenAjax');
add_action('wp_ajax_nopriv_cssGenAjax', 'cssGenAjax');

function cssGenAjax() {

            check_ajax_referer('ajax-human-nonce', 'nonce');
//wp_send_json_success($_POST);
            if (true) {

                        if (isset($_POST['new_section']) && !empty($_POST['new_section'])) {
                                    $new_section = sanitize_text_field($_POST['new_section']);
                                    if (!isset(get_option('human_css_sections')[$new_section])) {
                                                $sections = get_option('human_css_sections');
                                                $sections[$new_section] = ucwords(str_replace('_', ' ', $new_section));

                                                update_option('human_css_sections', $sections);
                                                $rep = $new_section;
                                    } else {
                                                $rep = 'exist';
                                    }
                                    $response = array(
                                        'new_section' => '' . $rep . ''
                                    );
                        } elseif (isset($_POST['new_section']) && empty($_POST['new_section'])) {
                                    $rep = 'empty';
                                    $response = array(
                                        'new_section' => '' . $rep . ''
                                    );
                        } elseif (isset($_POST['style_gens_minified'])) {
                                    $style_gens = esc_html($_POST['style_gens']);

                                    $style_gens_minified = esc_html($_POST['style_gens_minified']);
                                    $auto = '';
                                    $saved = 'saved';
                                    $rep = 'saved';

                                    update_option('STYLE-GENS' . $auto, $style_gens);
                                    update_option('STYLE-GENS-MINIFIED' . $auto, $style_gens_minified);

                                    $response = array(
                                        'saved' => '' . $rep . ''
                                    );
                        } elseif (isset($_POST['del_section'])) {
                                    $sections = get_option('human_css_sections');
                                    $sections[$_POST['del_section']] = null;
                                    $sections = array_filter($sections);
                                    update_option('human_css_sections', $sections);

                                    $response = array(
                                        'del_section' => 'Section ' . $_POST['del_section'] . ' - deleted!');
                        } elseif (isset($_POST['css_url'])) {

                                    $response = array(
                                        'url' => file_get_contents($_POST['css_url']));
                        } elseif (isset($_POST['newcolor'])) {
                                    $colors = get_option('human-color-palette');
                                    $colors[$_POST['newcolor']] = $_POST['newcolor'];
                                    update_option('human-color-palette', $colors);
                                    $response = human_palette_colors();
                        } elseif (isset($_POST['delete_color'])) {
                                    $colors = get_option('human-color-palette');
                                    unset($colors[$_POST['delete_color']]);
                                    update_option('human-color-palette', $colors);
                                    $response = human_palette_colors();
                        } else {
                                    $response = array(
                                        'error' => 'Data Error.');
                        }

                        wp_send_json_success($response);
            } else {
                        wp_send_json_success(array(
                            'error' => 'Wrong Nonce.'));
            }
}

function human_palette_colors() {
            $colors = get_option('human-color-palette');
            $palette = '';
            foreach ($colors as $k => $v) {
                        $palette .= '<div class="palette-holder-wrapper" style="float:left"><span class="palette-holder" data-color="' . $v . '" style="width:20px;height:20px;background:' . $v . ';cursor:pointer;display:block"></span><span style="font-size: 9px!important;
    position: relative;
    top: -30px;
    right: -1px;" class="fa fa-times delete-palette"  data-color="' . $v . '"></span>&nbsp;</div>';
            }
            $response = array(
                'colors' => $palette . '<div style="clear:both"></div>');
            return $response;
}

function load_css_gen() {
            if (current_user_can('administrator')) {

                        echo '<link href="' . HUMAN_BASE_URL . 'friends/css-gen/f-character/mood/css-gen-admin.css" type="text/css" rel="stylesheet">';

                        echo '<div style="display:none;" class="css-draggable human-compose-mode-css-gen grey">';
                        require HUMAN_BASE_PATH . 'friends/css-gen/f-face/css-gen-admin-user.php';
                        echo '</div>';

                        echo '
                      <div class="human-loading-gif-wrapper"> <div class="human-loading-gif"></div></div>';
            }
}

function load_css_gen_scripts() {

            wp_dequeue_script('jquery');
            wp_enqueue_media();
            wp_enqueue_script('media-upload');

            wp_enqueue_script('jquery');
            wp_enqueue_script('jquery-ui');
            wp_enqueue_script('jquery-ui-draggable');
            wp_enqueue_style('wp-color-picker');
            wp_enqueue_style('wp-color-picker');
            wp_enqueue_script('iris', admin_url('js/iris.min.js'), array(
                'jquery-ui-draggable',
                'jquery-ui-slider',
                'jquery-touch-punch'), false, 1);
            wp_enqueue_script('wp-color-picker', admin_url('js/color-picker.min.js'), array(
                'iris'), false, 1);
            $colorpicker_l10n = array(
                'clear' => __('Clear'),
                'defaultString' => __('Default'),
                'pick' => __('Select Color'));
            // wp_localize_script( 'wp-color-picker', 'wpColorPickerL10n', $colorpicker_l10n );

            wp_enqueue_script('css-gen-update-css', HUMAN_BASE_URL . 'friends/css-gen/f-character/temper/update.css.js', array(
                'wp-color-picker'));
            wp_enqueue_script('css-gen-select-tag', HUMAN_BASE_URL . 'friends/css-gen/f-character/temper/select.tag.js', array(
                'css-gen-update-css'));
            wp_enqueue_script('css-gen-script', HUMAN_BASE_URL . 'friends/css-gen/f-character/temper/script.js', array(
                'css-gen-select-tag'));
}

if (isset($_GET['vc_action']) && $_GET['vc_action'] === 'vc_inline' && current_user_can('administrator')) {
            load_css_gen();
            add_action('wp_enqueue_scripts', 'load_css_gen_scripts');
}

function my_mce4_options($init) {
            $default_colours = '
    "000000", "Black",
    "993300", "Burnt orange",
    "333300", "Dark olive",
    "003300", "Dark green",
    "003366", "Dark azure",
    "000080", "Navy Blue",
    "333399", "Indigo",
    "333333", "Very dark gray",
    "800000", "Maroon",
    "FF6600", "Orange",
    "808000", "Olive",
    "008000", "Green",
    "008080", "Teal",
    "0000FF", "Blue",
    "666699", "Grayish blue",
    "808080", "Gray",
    "FF0000", "Red",
    "FF9900", "Amber",
    "99CC00", "Yellow green",
    "339966", "Sea green",
    "33CCCC", "Turquoise",
    "3366FF", "Royal blue",
    "800080", "Purple",
    "999999", "Medium gray",
    "FF00FF", "Magenta",
    "FFCC00", "Gold",
    "FFFF00", "Yellow",
    "00FF00", "Lime",
    "00FFFF", "Aqua",
    "00CCFF", "Sky blue",
    "993366", "Brown",
    "C0C0C0", "Silver",
    "FF99CC", "Pink",
    "FFCC99", "Peach",
    "FFFF99", "Light yellow",
    "CCFFCC", "Pale green",
    "CCFFFF", "Pale cyan",
    "99CCFF", "Light sky blue",
    "CC99FF", "Plum",
    "FFFFFF", "White"
    ';
            $custom_colours = '
    "e14d43", "Color 1 Name",
    "d83131", "Color 2 Name",
    "ed1c24", "Color 3 Name",
    "f99b1c", "Color 4 Name",
    "50b848", "Color 5 Name",
    "00a859", "Color 6 Name",
    "00aae7", "Color 7 Name",
    "282828", "Color 8 Name"
    ';
            $init['textcolor_map'] = '[' . $default_colours . ',' . $custom_colours . ']';
            $init['textcolor_rows'] = 6; // expand colour grid to 6 rows
            return $init;
}

add_filter('tiny_mce_before_init', 'my_mce4_options');
