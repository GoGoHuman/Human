

function update_css_media_holder(elem, img) {
            var $ = jQuery;
            var css_id = $('input[name="' + elem.replace(/(\r\n|\n|\r)/gm, "").replace(/ /g, '')).attr('id');

            if (img === 1) {
                        $('#' + css_id + '-holder').empty();
            } else {

                        $('#' + css_id + '-holder').html('<img src="' + img + '" alt="" style="width:40px;height:40px">');
            }

}


function save_css_gen_ajax(save) {
            var save_template = 0;
            if (save > '' && save !== 0) {
                        save_template = save;
            }
            var action = 'cssGenAjax';
            var ajaxurl = humanAjax.ajaxurl;
            $ = jQuery;
            var data = {
                        action: action,
                        nonce: humanAjax.nonce,
                        style_gens_minified: $("#vc_inline-frame").contents().find("#human_temp_css_holder").find('style').html(),
                        style_gens: $('.all-gens').html(),
                        custom_css: $("#vc_inline-frame").contents().find("#custom-css-style-holder").find('style').html(),
                        autosave: 'normal',
                        save_template: save_template
            };
            // console.log(data);
            toggle_human_gif();
            console.log('CSS Builder update started');
            $.post(ajaxurl, data, function (response) {
                        console.log(response);
                        if (response['data']['error']) {

                        } else {
                                    //    console.log(response);
                                    //alert('CSS Saved!');
                                    $('#css-is-saved').val(1);
                                    $('#autosaved').text(response.data['saved']);
                                    setTimeout(function () {
                                                //    var save = 'auto';

                                                toggle_human_gif('hide');
                                    }, 10000);

                        }
            });

}
function html_css_bar(folder, section, tag) {
            return  '<div class="html-css-bar"><table><tr><td><span class="del-css-selector">[x]</span></td><td><button class="select-css">edit</button></td><td><span class="handle fa fa-arrows"></span></td></tr></table></div>';
}

function update_css_holders(s_styles, selected_tag, propname) {


            $ = jQuery;
            var resolution_start = '';
            var resolution_end = '';
            var resolution_style_id = '';
            var resolution = '';
            if ($('#human_screen_res').val()) {
                        var resolution_start = '@media and screen (min-width:' + $('#human_screen_res').val() + 'px){ ';
                        var resolution_end = ' }';
                        var resolution_style_id = $('#human_screen_res').val();
                        var resolution = '-' + $('#human_screen_res').val();
            }
            var s_styles = replaceAll(s_styles, '&#039;', '"');
            var propname = replaceAll(propname, '"', '-');
            var temp_style_id = 's_' + resolution_style_id + replaceAll(propname, ',', '');
            var html_css_bars = html_css_bar();

            var temp_styles = html_css_bars + '<div class="styles">' + selected_tag + '\n' + '{ \n' +
                    s_styles + '\n} </div>';
            if ($('#' + temp_style_id).length == 0) {

                        $('#temp-css' + resolution).append('<div id="' + temp_style_id + '"  css-folder="' + $('#template_wraps').val() + '" css-section="' + $('#custom_sections').val() + '" css-tag="' + selected_tag + '" >' + temp_styles + '</div>');
                        //console.log(temp_style_id+' = doesn\'t exists');


            } else {

                        //console.log(getElementById(temp_style_id));
                        $("#" + temp_style_id).empty();
                        //  console.log($('#'+temp_style_id).html());
                        $("#" + temp_style_id).append(temp_styles);


            }
            var all_styles = '';
            var all_temp_styles = '';
            $.each($('#temp-css .styles'), function () {

                        all_styles += $(this).html();
                        all_temp_styles += $(this).html();
            });

            var resolution = $('#human_screen_res').val();
            $.each($('.resolutions'), function () {
                        var and = '';
                        var res_number = parseInt($(this).attr('id').replace('temp-css-', ''));
                        if (res_number == 320) {
                                    var to_res = '(max-width: 320px)';
                        } else if (res_number == 480) {
                                    var to_res = '(max-width: 480px)';
                        } else if (res_number == 768) {
                                    var to_res = '(max-width: 768px)';
                        } else if (res_number == 968) {
                                    var to_res = '(max-width: 968px)';
                        } else if (res_number == 1024) {
                                    var to_res = '(max-width: 1024px)';
                        }
                        all_styles += '@media screen and ' + to_res + '{ ';
                        all_temp_styles += '@media screen and ' + to_res + '{ ';
                        $(this).find('.styles').each(function () {

                                    all_styles += $(this).html();
                                    if (resolution) {
                                                if (res_number <= resolution) {
                                                            all_temp_styles += $(this).html();

                                                            //  console.log(resolution+'-'+res_number);
                                                }
                                    } else {
                                                all_temp_styles += $(this).html();
                                    }
                        });
                        all_styles += ' }';
                        all_temp_styles += ' }';
            });

            var ready = replaceAll(all_styles, '.human-page .human-page', '.human-page');
            ready = replaceAll(ready, '&gt;', '>').replace('&amp;gt;', '>');
            var ready_temp = replaceAll(all_temp_styles, '.human-page .human-page', '.human-page');
            //  $('.gen-window').html(replaceAll(ready, '.human_select', '').replace(/\r?\n/g, '<br>'));
            // $('.gen-holder').html('<style type="text/css">' + replaceAll(ready, '.human_select', '') + '</style>');


            if ($("#vc_inline-frame").length > 0) {

                        if ($("#vc_inline-frame").contents().find('#human_temp_css_holder').length === 0) {

                                    $("#vc_inline-frame").contents().find('#human-dynamic-css-css').remove();
                                    $("#vc_inline-frame").contents().find("body").prepend('<div id="human_temp_css_holder"></div><div id="custom-css-style-holder"></div>');

                        }


                        $("#vc_inline-frame").contents().find("#human_temp_css_holder").html('<style media="all">' + ready + '</style>');
                        $("#vc_inline-frame").contents().find("#custom-css-style-holder").html('<style media="all">' + $('#human-custom-css').val() + '</style>');


            }



}

function update_css() {
            var $ = jQuery;
            if ($('#selected_tag').val()) {


                        var propnames = $('#selected_tag').val();
                        var allcontrols = $(".controls_inner").find("input,select");

                        var s_styles = "";
                        var align = $('#text-align-holder').val();
                        $('.human-align').css('opacity', 1);
                        $('*[data-align="' + align + '"]').css('opacity', 0.5);

                        $.each(allcontrols, function () {

                                    var pval = $(this).val();
                                    var pname = $(this).attr('name');
                                    if ($(this).attr('id') !== 'selected_tag') {
                                                if (typeof pval !== 'undefined' && typeof pname !== 'undefined') {
                                                            if (pval) {

                                                                        if (pname === 'background-image' || pname === 'list-style-image') {
                                                                                    if (pval != 'none') {
                                                                                                // pval = '/wp-content'+ pval.split('wp-content')[1];
                                                                                                pval = 'url("' + pval + '")';
                                                                                                // console.log(pval);
                                                                                    } else {
                                                                                                pval = pval;
                                                                                    }
                                                                        } else if (pname.indexOf('color') > -1) {

                                                                        } else {
                                                                                    if ($('#' + pname + '-unit').length > 0) {
                                                                                                var unit = $('#' + pname + '-unit').val();
                                                                                    } else {
                                                                                                var unit = '';
                                                                                    }
                                                                                    var pval = pval + unit;


                                                                        }
                                                                        s_styles += pname + ':' + pval + ';\r';

                                                            }
                                                }
                                    }

                        });

                        //  $('#s_'+propname).remove();
                        var selected_tag = jQuery('#selected_tag').val();
                        if (selected_tag.indexOf('placeholder') > -1) {
                                    var selected_tag = $('#human_sections').val() + ' .placeholder,*::-webkit-input-placeholder, *::-moz-placeholder, *:-ms-input-placeholder,*:-moz-placeholder';
                                    selected_tag = selected_tag.split(',');
                                    $.each(selected_tag, function () {


                                                var propnames = this.replace(/\W+/g, "_");
                                                var propname = propnames;
                                                update_css_holders(s_styles, this, propname);

                                    });

                                    return;
                        }

                        var propnames = selected_tag.replace(/\W+/g, "_");

                        var propname = propnames;

                        update_css_holders(s_styles, selected_tag, propname);

                        current_color_pallete();
                        return;
            } else {

                        alert('Please select an element(s)');
                        return;
            }

}

