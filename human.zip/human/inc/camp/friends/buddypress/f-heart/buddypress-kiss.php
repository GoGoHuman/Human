<?php

//add_theme_support('buddypress');

