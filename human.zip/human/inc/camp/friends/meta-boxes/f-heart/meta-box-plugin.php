<?php

add_filter ( 'rwmb_meta_boxes', 'human_register_meta_boxes' );

function human_register_meta_boxes ( $meta_boxes ) {
            $post_types = [ ];
            if ( get_option ( 'human_attachments' ) ) {
                        $post_types = explode ( ',', get_option ( 'human_attachments' ) );
            }

            $meta_boxes[] = array (
                        'id' => 'attachments',
                        'title' => __ ( 'Attachments', 'textdomain' ),
                        'post_types' => $post_types,
                        'context' => 'normal',
                        'priority' => 'high',
                        'fields' => array (
                                    array (
                                                'name' => __ ( 'Attachment', 'textdomain' ),
                                                'desc' => 'Assign Attachment',
                                                'id' => 'human_attachment',
                                                'type' => 'image',
                                                'std' => 'Anh Tran',
                                                'class' => 'custom-class',
                                                'clone' => true,
                                    ),
                        )
            );

            return $meta_boxes;
}
