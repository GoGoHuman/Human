<?php

function meta_template ( $meta ) {

            $meta_template[] = '<div class="human-meta-child">';

            $meta_template[] = '<h3>' . $meta[ 'title' ] . '</h3>';

            $meta_template[] = '<p>' . $meta[ 'desc' ] . '</p>';
            // return 'in<hr>' . $meta[ 'type' ];
            if ( $meta[ 'type' ] === 'image' ) {
                        $link_bg = '';
                        if ( isset ( $meta[ 'value' ] ) && ! empty ( $meta[ 'value' ] ) ) {
                                    $link_bg = 'background:url("' . $meta[ 'value' ] . '")';
                        }
                        $meta_template[] = '<div class="human-controls human-media-wrapper">
                                                                        <a class="human-media" style="' . $link_bg . '">upload </a>
                                                                        <span class="fa fa-close human-del-media"></span>
                                                                        <input type="text" class="human_media_holder" value="' . $meta[ 'value' ] . '">
                                              </div>';
            }
            elseif ( $meta[ 'type' ] === 'text' ) {
                        $meta_template[] = '<div class="human-controls human-text-wrapper">
                                                                       <input type="text" class="human-meta-textfield" value="' . $meta[ 'value' ] . '">
                                             </div>';
            }
            elseif ( $meta[ 'type' ] === 'wysiwyg' ) {
                        $content = $meta[ 'value' ];
                        $editor_id = $meta[ 'id' ];

                        $meta_template[] = '<div class="human-controls human-tiny-wrapper"><link rel="stylesheet" id="editor-buttons-css" href="http://localhost/human-templates/food/wp-includes/css/editor.css?ver=4.6" type="text/css" media="all">';
                        $meta_template[] = '<div id="wp-content-editor-tools" class="wp-editor-tools hide-if-no-js" style="position: absolute; top: 0px; width: 847px;">

                                                            <div id="wp-content-media-buttons" class="wp-media-buttons">
                                                                   <button type="button" id="insert-media-button" class="button insert-media add_media" data-editor="content">
                                                                       <span class="wp-media-buttons-icon"></span>
                                                                       Add Media
                                                                   </button>
                                                            </div>
                                                            <div class="wp-editor-tabs">
                                                                <button type="button" id="content-tmce" class="wp-switch-editor switch-tmce" data-wp-editor-id="content">Visual</button>
                                                                <button type="button" id="content-html" class="wp-switch-editor switch-html" data-wp-editor-id="content">Text</button>
                                                            </div>
                                                         </div>

                         <textarea name="' . strtolower ( str_replace ( ' ', '_', $meta[ 'title' ] ) ) . '" id="' . $editor_id . '" aria-hidden="true" style="display: none;"></textarea>
                         ';
                        $meta_template[] = '</div>';
            }
            else {
                        return array (
                                    'error - wrong type',
                                    $meta );
            }


            $meta_template[] = '</div>';


            return implode ( $meta_template );
}
