<?php

function human_public_post_types($all = null) {
            $args = array(
                'public' => true,
                'exclude_from_search' => false
            );

            $output = 'names'; // names or objects, note names is the default
            $operator = 'and'; // 'and' or 'or'

            $post_types = get_post_types($args, $output, $operator);

            $post_types = str_replace(',attachment', '', implode(',', $post_types));


            return $post_types;
}

function load_cache_scripts() {

            $cpt = human_public_post_types();
            wp_enqueue_script('cache-builder', HUMAN_FRIENDS_URL . '/cache/f-character/temper/cache-admin.js', array('jquery'));
            if (is_admin()) {
                        $isadmin = 'isadmin';
                        $post_id = '';
            } else {
                        $isadmin = '';
                        $post_id = get_the_ID();
            }
            wp_localize_script('cache-builder', 'human_cpt', array(
                'human_cpts' => $cpt,
                'isadmin' => $isadmin,
                'post_id' => $post_id,
                'ajaxurl' => admin_url('admin-ajax.php'),
                'adminUrl' => admin_url() . 'admin.php?page=human-cache-settings',
                'nonce' => wp_create_nonce('ajax-human-nonce'),
            ));
            wp_enqueue_style('tokenize-css', HUMAN_BASE_URL . '/h-helpers/multi-select/jquery.tokenize.css');
            wp_enqueue_script('tokenize', HUMAN_BASE_URL . '/h-helpers/multi-select/jquery.tokenize.js', array('jquery'));
}

function makeDir($path) {
//         /   print_r($path);
            return is_dir($path) || mkdir($path);
}

if (current_user_can('edit_posts')) {

            $cacheLocation = ABSPATH . 'wp-content/human-cache/';
            if (!is_file($cacheLocation)) {
                        makeDir(ABSPATH . 'wp-content/human-cache/');
            }
            add_action('wp_enqueue_scripts', 'load_cache_scripts');
            add_action('admin_enqueue_scripts', 'load_cache_scripts');
}

function url_protocol() {
            return stripos($_SERVER['SERVER_PROTOCOL'], 'https') === true ? 'https://' : 'http://';
}

function init_post_id() {

            return url_to_postid(url_protocol() . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI']);
}

function human_cache_creator($id = null) {
            $protocol = url_protocol();
            // print_r($protocol . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'] . '/?create-cache=1');
            if (!isset($id)) {
                        return;
            } else {
                        $url = get_permalink($id);
            }
            // print_r($url);
            $content = file_get_contents($url . '?create-cache=1');
            $path = ABSPATH . 'wp-content/human-cache/cache-' . $id . '.html';
            $file = fopen($path, "w") or die("Unable to create or open Human cache file!");

            fwrite($file, $content);
            fclose($file);
}

function rrmdir($src) {
            if (!file_exists($src)) {
                        return;
            }
            $dir = opendir($src);
            while (false !== ( $file = readdir($dir))) {
                        if (( $file != '.' ) && ( $file != '..' )) {
                                    $full = $src . '/' . $file;
                                    if (is_dir($full)) {
                                                rrmdir($full);
                                    } else {
                                                unlink($full);
                                    }
                        }
            }
            closedir($dir);
            rmdir($src);
}

//      add_action('wp_head', 'human_safe_redirect');

function human_safe_redirect() {
            $redirect_link = url_protocol() . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
            $r = '<script async>
                        if(getUrlParameter("clear-cache")){
                            alert("Selected cache has been cleared");
                            location.assign("' . explode('?', $redirect_link)[0] . '");
                        }
                     </script>';
            print_r($r);
}

function load_cache() {
            if (is_file(ABSPATH . 'wp-content/human-cache/cache-' . init_post_id() . '.html')) {


                        $script = '<script> $(".post-title h1").append(\'<div style="position:relative;right:10px;float:right">This page loaded in ' . code_tester() . ' - Speed your website with Human Cache </div> \');</script></body>';
                        $str = file_get_contents(ABSPATH . 'wp-content/human-cache/cache-' . init_post_id() . '.html');
                        echo str_replace('</body>', $script, trim($str));
                        exit;
            } else {
                        if (!isset($_GET['clear-cache'])) {
                                    // human_cache_creator();
                        }
            }
            // code_tester();
}

if (!is_admin() && !current_user_can('edit_posts') && get_option('disable_human_cache') !== 2) {
            //   add_action('init', 'load_cache', 1);
}

function human_script_minifier() {
            global $wp_scripts, $wp_styles;
            $i = $j = 0;

            function compress($buffer) {
                        /* remove comments */
                        $buffer = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $buffer);
                        /* remove tabs, spaces, newlines, etc. */
                        $buffer = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $buffer);
                        return $buffer;
            }

            ob_start("compress");
            foreach ($wp_styles->queue as $handle) {
                        $i++;
                        $obj = $wp_styles->registered [$handle];
                        $filename = $obj->src;
                        //   $styles = '';
                        $scripts = '';
                        if (strpos($filename, '//') !== false) {
                                    if (strpos($filename, 'http') === false) {
                                                $filename = 'http:' . $filename;
                                    }
                                    //print_r(file_get_contents($filename));
                                    $s += file_get_contents($filename);
                        }
            }
            ob_end_flush();
            foreach ($wp_scripts->queue as $handle) {
                        $j++;
                        if ($handle !== 'jquery') {
                                    $obj = $wp_scripts->registered [$handle];
                                    $filename = $obj->src;
                                    if (strpos($filename, '//') !== false) {
                                                if (strpos($filename, 'http') === false) {
                                                            $filename = 'http:' . $filename;
                                                }
                                                $scripts += file_get_contents($filename);
                                    }
                        }
            }

            print_r('<pre><script>' . $scripts . '</script></pre>');
}

if (current_user_can('edit_posts')) {
            add_action('wp_print_scripts', 'human_script_minifier');
}

function cacheAssigner($loop) {
            foreach ($loop as $post) {
                        human_cache_creator($post->ID);
            }
}

function human_remove_cache($id) {
            if (is_file(ABSPATH . 'wp-content/human-cache/cache-' . $id . '.html'))
                        unlink(ABSPATH . 'wp-content/human-cache/cache-' . $id . '.html');
}

function human_remove_id_cache() {
            $posts = get_option('excluded_posts');
            if (!empty($posts)) {
                        foreach ($posts as $post) {
                                    human_remove_cache($post);
                        }
            }
}

function human_remove_post_type_cache() {

            $cpts = get_option('excluded_post_types');
            if (!empty($cpts)) {
                        $args = array('post_status' => 'publish', 'post_type' => $cpts);
//print_r($args);
                        $posts = get_posts($args);
//print_r($posts);

                        foreach ($posts as $post) {
                                    human_remove_cache($post->ID);
                        }
            }
}

function human_rebuild_cache() {
            human_remove_post_type_cache();
            human_remove_id_cache();
}

add_action('wp_ajax_cptAjax', 'cptAjax');
add_action('wp_ajax_nopriv_cptAjax', 'cptAjax');

function cptAjax() {

            //wp_send_json_success(array('error' => 'Wrong Nonce.'));
            check_ajax_referer('ajax-human-nonce', 'nonce');

            if (true) {

                        function cache_shutdown($respond) {

                                    human_rebuild_cache();
                        }

                        $cacheType = $_POST['cachetype'];
                        $cached = $_POST['cached'];
                        //print_r($cached);
                        update_option('human_transient', '');

                        if ($cacheType === 'all') {
                                    $args = array('post_status' => 'publish', 'post_type' => explode(',', $cached));
                                    $loop = get_posts($args);
                                    cacheAssigner($loop);
                        } elseif ($cacheType === 'thispage') {
                                    human_cache_creator($cached);
                        } elseif ($cacheType === 'post_type') {
                                    $args = array('post_type' => $cached, 'post_status' => 'publish');
                                    $loop = get_posts($args);
                                    cacheAssigner($loop);
                        }
                        if (isset($loop)) {
                                    $i = 0;
                                    foreach ($loop as $post) {
                                                $i++;
                                                $respond['titles'][$i] = $post->post_title;
                                    }
                        } else {
                                    $respond['titles'][1] = get_permalink($cached);
                        }
                        $respond = implode(',', $respond['titles']);

                        register_shutdown_function('cache_shutdown', $respond);
                        wp_send_json_success(array('success' => $respond));
            } else {
                        wp_send_json_success(array('error' => 'Wrong Nonce.'));
            }
}
