<?php
if (isset($_POST['disable_human_cache'])) {
            update_option('disable_human_cache', $_POST['disable_human_cache']);
}
$on = 'checked';
$off = '';
if (get_option('disable_human_cache') == 2) {
            $on = '';

            $off = 'checked';
}
?>

<h2>Cache Status</h2>
<form method="post">
    <input type="radio" name="disable_human_cache"  value="1" <?php
    echo $on;
    ?>>::Enabled<br>
    <input type="radio" name="disable_human_cache"  value="2" <?php
    echo $off;
    ?>>::Disabled
    <br><br>
    <button type="submit">Update</button>

</form>
<h2>Build Cache</h2>
<ul class="ab-submenu admin-cache-dropdown">
    <li>
        <a href="#" class="ab-item" data-cachetype="all" data-cached="<?php echo human_public_post_types(); ?>">Rebuild All</a>
    </li>
    <?php
    $cpts = explode(',', human_public_post_types());
    foreach ($cpts as $cpt) {
                echo '<li><a href="#" class="ab-item"  data-cachetype="post_type" data-cached="' . $cpt . '">Rebuild ' . ucwords($cpt) . '</a></li>';
    }
    ?>
</ul>
<hr>
<?php
if (isset($_POST['cache'])) {
            if (isset($_POST['excluded_post_types'])) {
                        update_option('excluded_post_types', $_POST['excluded_post_types']);
            } elseif (!isset($_POST['excluded_post_types'])) {
                        update_option('excluded_post_types', '');
            }
            if (isset($_POST['excluded_posts'])) {
                        update_option('excluded_posts', $_POST['excluded_posts']);
            } elseif (!isset($_POST['excluded_posts'])) {
                        update_option('excluded_posts', '');
            }
            human_rebuild_cache();
}
?>
<form method="post">
    <input type="hidden" name="cache" value="1">
    <h3>Disable Cache for post types</h3>
    <select class="tokenize tokenize-sample" name="excluded_post_types[]" multiple>
        <?php
        foreach ($cpts as $cpt) {
                    $selected = '';
                    if (in_array($cpt, get_option('excluded_post_types'))) {
                                $selected = "selected";
                    }

                    echo '<option value="' . $cpt . '" ' . $selected . '> ' . ucwords($cpt) . '</option>';
        }
        ?>
    </select>
    <h3>Disable Individual Posts/Pages</h3>

    <select class="tokenize tokenize-sample" name="excluded_posts[]" multiple>
        <?php
        $args = array('post_status' => 'publish', 'post_type' => $cpts);
//print_r($args);
        $posts = get_posts($args);
//print_r($posts);
        foreach ($posts as $post) {
                    $selected = '';

                    //print_r(get_option('excluded_posts'));
                    if (in_array($post->ID, get_option('excluded_posts'))) {
                                $selected = "selected";
                    }
                    echo '<option value="' . $post->ID . '" ' . $selected . '> ' . ucwords($post->post_title) . '</option>';
        }
        ?>
    </select>
    <p>&nbsp;</p>
    <button type="submit">Update</button>

</form>
<hr>
<script>
            jQuery('.tokenize').tokenize({displayDropdownOnFocus: true});
</script>