/*
 *  @param  cache processing 
 */

jQuery(document).ready(function($){
    
    
    var human_cpts = human_cpt['human_cpts'].split(',');
    
    var cps = '';var cpss='';
    $(human_cpts).each(function(){
           cps += '<li id="'+this+'"><a href="#" class="ab-item capitalize"  data-cachetype="post_type" data-cached="'+this+'">Rebuid '+this+'</a></li>';
           cpss += ','+this;
    });
    var pagenow='<li><a href="#" class="ab-item" data-cachetype="thispage" data-cached="'+human_cpt['post_id']+'">Rebuild This Page</a></li>';
   
    if(human_cpt['isadmin'] ===  'isadmin'){
          pagenow = '';
    }
    $('<li id="admin-cache-dropdown" class="menupop"><a href="'+human_cpt['adminUrl']+'" class="ab-item" aria-haspopup="true">Cache Settings</a><div class="ab-sub-wrapper"><ul class="ab-submenu">'+pagenow+'<li><a href="#" class="ab-item" data-cachetype="all" data-cached="post,page'+cpss+'">Rebuild All</a></li>'+cps+'</ul></div></li>').insertAfter('#wp-admin-bar-my-account');
    
    $('#admin-cache-dropdown .ab-submenu li a,.admin-cache-dropdown li a').live('click',function(e){
        
        e.preventDefault();
        e.stopPropagation();
           var cachetype = $(this).data('cachetype');
           var cached = $(this).data('cached');
          
           var ajaxurl = human_cpt.ajaxurl;
           var data = {
            action:'cptAjax',
            cachetype: cachetype,
            nonce: human_cpt.nonce,
            cached:cached
           };
        console.log(data);
                alert('Cache is building..., \n'
               + 'Please allow few minutes before testing');
        $.post(ajaxurl, data, function (response) {
            console.log(response);
            if (response.data && response.data['error']){
                                
            } else {
            }});
    });
    
});