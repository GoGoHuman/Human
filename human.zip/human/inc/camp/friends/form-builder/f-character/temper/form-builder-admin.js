jQuery(document).ready(function($){
    
    
          $('#wpb-save-post,#publish').on('click',function(e){
                
           if($('#title').val().indexOf('Comment Form') > -1 && $('#post_type').val() === 'human_forms'){
               //e.preventDefault();
                var elem_names=[];
                 $('div.name.elem_name').each(function(){
                        
                        if($(this).html().length >0){
                            //alert($(this).html());
                           elem_names.push($(this).html());
                        }
                        
                 });
               //  console.log(elem_names);
                       var data = {
                                      action: "cssFormAjax",
                                      nonce: humanAjax.nonce,
                                      form_type: 'comment_meta',
                                      comment_metas: elem_names,
                                      comment_form:$('#post_ID').val()
                                      
                              };
                         /*      console.log(data);
                                   $.post(humanAjax.ajaxurl, data, function (response) {
                                   //         console.log(response);
                                            if (response.success) {
                                                   
                                                    $('#post').submit();
                                           } else {
                                                    alert('There was a problem to save Human Comment Meta Fields - Please report this bug to Human Support referencing ID:COMMENT-A-M');
                                                   
                                                    $('#post').submit(); 
                                       }
                                 });*/
             //   $('#post').submit();
             }else{        
                // alert('false');
                $('#post').submit();
             }
             //    $(this).unbind('submit').submit()
          });
   
    
});