<?php
 echo "I am Silent Human.";
?>