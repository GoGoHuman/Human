<?php

add_action('init', 'add_member_url');

function add_member_url() {


            //   add_rewrite_rule('^camper/(.+?)/(.+?)/?$', 'index.php?pagename=camper&user_meta=$matches[1]&user_meta_value=$matches[2]', 'top' );
            add_rewrite_rule(
                    '^member/(.+?)/?$', 'index.php?pagename=member&user_nicename=$matches[1]', 'top'
            );

            //add_rewrite_tag('%g_id%', '([^/]*)');
}

function human_users_query_vars($vars) {
            $vars[] = 'user_meta';
            $vars[] = 'user_nicename';
            $vars[] = 'user_meta_value';
            return $vars;
}

add_filter('query_vars', 'human_users_query_vars');

flush_rewrite_rules();

//add_shortcode('human_members', 'human_members');

function human_get_user_by_nice_name($nicename, $type = '') {
            global $wpdb;
            if (!empty($type)) {
                        $ID = 'user_id';

                        $nice_table = $wpdb->prefix . "usermeta";

                        $sql = "SELECT $ID FROM $nice_table WHERE meta_key = '$type' AND meta_value = '$nicename'";
            } else {
                        $ID = 'ID';
                        $type = 'user_nicename';

                        $nice_table = $wpdb->prefix . "users";

                        $sql = "SELECT $ID FROM $nice_table WHERE $type = '$nicename'";
            }

            $user_id = $wpdb->get_var($sql);
            //print_r($user_id);
            return $user_id;
}

function human_identify_user($id, $type = '') {

            $type_id = $id;

            //print_r($type_id);
            //print_r($type);
            if (!empty($type)) {
                        return human_get_user_by_nice_name($type, $id);
            } else {
                        //  print_r($type_id);
                        if (human_get_user_by_nice_name($type_id)) {
                                    //   print_r($type_id);
                                    return human_get_user_by_nice_name($type_id);
                        }
            }
}

function human_members() {
            // echo get_query_var('user_nicename') . '<hr>';
            if (get_query_var('user_nicename') !== null && !empty(get_query_var('user_nicename'))) {
                        //   header("Location: https://human.camp/campers/");
                        //   echo "<h3>Sorry this user does not exist</h3>";
                        return human_identify_user(get_query_var('user_nicename'));
            } elseif (get_query_var('user_meta') !== null && !empty(get_query_var('user_meta')) && get_query_var('user_meta_value') !== null && !empty(get_query_var('user_meta_value'))) {
                        return human_identify_user(get_query_var('user_meta'), get_query_var('user_meta_value'));
            }
}

add_shortcode('human_member_meta', 'human_member_meta');

function human_member_meta($attr = null) {


            $meta = $attr['member_meta'];
            if ($attr['member_meta'] === 'avatar') {
                        $current_user = get_user_by('ID', human_members());
                        $email = $current_user->user_email;
                        $res = human_user_avatar($email);
            } else {
                        if (null != get_user_meta(human_members(), $meta)) {
                                    $res = get_user_meta(human_members(), $meta)[0];
                        } else {
                                    $res = '';
                        }
            }
            //print_r(human_members());
            $wrap = '<div class="human-meta-' . $attr['member_meta'] . '">' . $res . '</div>';
            return $wrap;
}

add_action('vc_before_init', 'vc_human_member_meta');

function vc_human_member_meta() {
            vc_map(array(
                "name" => __("Human Member Meta", "human"),
                "base" => "human_member_meta",
                "class" => "human_member_meta",
                "category" => __("Human Content", "human"),
                "icon" => human_icon(),
                "params" => array(
                    array(
                        "type" => "textfield",
                        "holder" => "div",
                        "class" => "human_member_meta_field",
                        "heading" => __("Member - Meta", "human"),
                        "param_name" => "member_meta",
                        "description" => __("e.g. first_name, last_name, nick_name, avatar
                                                           <br>Full details explaned in ", "human") . "<a href='https://human.camp/academy/contents/user-meta'>https://human.camp/academy/contents/user-meta</a>",
                    )
                ),
            ));
}
