<?php

//add_shortcode('human_sms', 'human_sms');

function human_sms() {

    require HUMAN_BASE_PATH . 'friends/human-sms-kiss.php';
    $client = new MScience\SmsClient('', '');
    if (isset($_POST['phone'])) {
        $phone = $_POST['phone'];
        $content = $_POST['content'];
    }

    $result2 = $client->send(array(new MScience\SmsMessage('', $phone, 0, $content, true)));
    print_r( $result2 );
    return '<form method="POST"><input type="text" placeholder="phone" name="phone"><textarea name="content"></textarea><button type="submit"></button></form>';
}
